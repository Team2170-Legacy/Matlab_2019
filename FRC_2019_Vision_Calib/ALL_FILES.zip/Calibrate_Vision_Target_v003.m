%   Calibrate_Vision_Target_v003.m
%   Written on 3/15/2019
%   Jacob Krucinski (jacob1576@gmail.com)
clc;
close all;
clear all;

img_1_path = 'Images/VisionTarget1.jpg';
img_1 = imread(img_1_path);

% Rotate the image so that vision targets are straight up and down
img_1 = imrotate(img_1, 14.5);
% Invert colors so that ginput cross hairs are more visible
imshow(uint8(255) - img_1);

% Use ginput to grab specific target (add code support for 2)
disp('Click in the upper left and then the lower right of the reflective tape...');
rectL = ginput(2);
roundedL = round(rectL);

disp('Click in the upper left and then the lower right of the reflective tape...');
rectR = ginput(2);
roundedR = round(rectR);

% Get target subsections from ginput
target_L = img_1( roundedL(1,2):rounded1(2,2) , roundedL(1,1):rounded1(2,1), : ); % x then y
target_R = img_1( roundedR(1,2):rounded2(2,2) , roundedR(1,1):rounded2(2,1), : ); % x then y

% Show target subsections in separate windows
imshow(target_L);
imshow(target_R);

